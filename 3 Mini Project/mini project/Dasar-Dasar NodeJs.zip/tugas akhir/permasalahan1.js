//permasalahan1;
jarak = 7*1000;
j= jarak;
waktu = 15*60;
t= waktu;
console.log("diketahui jarak = " +j+" meter");
console.log("diketahui waktu = " +t+" detik");
kecepatan = j/t;
console.log("Maka kecepatan motor pak eman adalah " +kecepatan+"meter/sekon");

//permasalahan2
console.log ("diketahui waktu = 10 detik");
t=10;
console.log ("diketahui kecepatan grafitasi = 10 m/s^2");
g=10;
console.log ("kecepatan awal = 0 m/s");
v0=0;
console.log ("gerakan jatuhbbas =v0 * t +(1/2*g*t*t");
h= v0*10+1/2*10*10*10;
console.log ("h= v0*10+(1/2*10*10*10");
console.log ("maka gerak jatuh bebasnya adalah "+h+" meter");


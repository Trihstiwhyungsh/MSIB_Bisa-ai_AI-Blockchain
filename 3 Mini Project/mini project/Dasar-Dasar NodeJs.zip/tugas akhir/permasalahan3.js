//permasalahn3
console.log ("diketahui kecepatan awal 54 m/s");
v1=54;
console.log ("diketahui keceptan akkhir 72 m/s");
v2=72;
console.log ("diketahui waktu wal = 0 detik");
console.log ("diketahui waktu akhir = 10 detik");
t1=0;
t2=10;
perubahan_kecepatan = v2-v1;
perubahan_waktu = t2-t1;
percepatan_rata_rata = perubahan_kecepatan/perubahan_waktu;
console.log ("percepatan rata-rata = perubahan kecepatan / perubaha waktu");
console.log ("maka kecepatan rata-rata motor pa eman adalah "+percepatan_rata_rata+"m/s^2")